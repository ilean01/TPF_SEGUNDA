/*
 ============================================================================
 Name        : TPF_2023.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */
#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "inicializaciones.h"
int turno=1;
int ll=0;
int summ;

GtkBuilder *builder;

//TODAS LAS VENTANAS
GtkWidget *VENTANA_INICIO;
GtkWidget *VENTANA_MODO_DE_JUEGO;
GtkWidget *VENTANA_CREDITOS;
GtkWidget *VENTANA_PUNTUACIONES;
GtkWidget *VENTANA_PARTIDAS;
GtkWidget *VENTANA_TABLERO;
GtkWidget *VENTANA_PERSONAJE;
GtkWidget *VENTANA_DOSJUGADORES;
GtkWidget *VENTANA_UNJUGADOR;
GtkWidget *VENTANA_PAUSA;
GtkWidget *VENTANA_COMO;
GtkWidget *VENTANA_GANADOR_ROJO;
GtkWidget *VENTANA_GANADOR_VERDE;
GtkWidget *VENTANA_QUIEN;

GtkWidget *SALIR_JUEGO;


//VENTANA QUIEN
GtkWidget *ATRAS_QUIEN;
GtkWidget *JUG1;
GtkWidget *JUG2;
GtkWidget *ALEA;

//VENTANA PUNTUACIONES
GtkWidget *ATRAS_PUNTUACIONES;
//VENTANA CREDITOS
GtkWidget *ATRAS_CREDITOS;

//VENTANAS PARTIDAS GUARDADAS
GtkWidget *ATRAS_PARTIDAS;
//VENTANA INICIO
GtkWidget *BOTON_INIC;
GtkWidget *BOTON_CREDITO;
GtkWidget *BOTON_PUNTUACIONES;
GtkWidget *BOTON_PARTIDAS;
GtkWidget *BOTON_SALIR;

//VENTANA MODO JUEGO
GtkWidget *HvsH;
GtkWidget *HvsC;
GtkWidget *CvsC;
GtkWidget *modo_aleatorio;
GtkWidget *atras_modo;

//VENTANA PERSONAJE
GtkWidget *PersonajeAleatorio;
GtkWidget *SERMARIO;
GtkWidget *SERLUIGI;
GtkWidget *ATRAS_PERSONAJE;

//VENTANA DOS JUGADORES
GtkWidget *LISTO_DOS_JUGADORES;
GtkWidget *ATRAS_DOS_JUGADORES;
GtkEntry  *JUGADOR1;
GtkEntry  *JUGADOR2;

//VENTANA UN JUGADOR
GtkWidget *ATRAS_UN_JUGADOR;
GtkWidget *LISTO_UN_JUGADOR;
GtkEntry  *JUGADOR_1;

//VENTANA TABLERO
GtkGrid   *GRID_TABLERO;
GtkImage *IMAGEN_TURNO;
GtkWidget *LABEL_TURNO;
GtkWidget *LABEL_AVISOS;
GtkWidget *botones_tablero[5][5];
GtkWidget *jugar_compu;

GtkWidget *LISTO_COMER;

GtkImage *arr;
GtkImage *aba;
GtkImage *derec;
GtkImage *izqui;
GtkImage *medio;
//VENTANA PAUSA
GtkWidget *BOTON_PAUSA;
GtkWidget*ATRAS_COMO;
GtkWidget *SEGUIR_JUGANDO;
GtkWidget*COMO_SE_JUEGA;
GtkWidget*VOLVER_AL_MENU;
GtkWidget*FINALIZAR;
GtkWidget*PAUSA_VERDE;
GtkWidget*PAUSA_RO;
GtkWidget*RELLENAR;


int main(int argc, char *argv[]) {
    gtk_init(&argc, &argv);
    builder = gtk_builder_new();
    if (builder == NULL) {
        g_print("Error al crear el constructor GTK Builder.\n");
        return 1;
    }
    inicializarMatriz();

    guint ret;
    GError *error = NULL;

    ret = gtk_builder_add_from_file(builder, "src/tpf_2023.glade", &error);
    if (ret == 0) {
        g_print("Error en la función gtk_builder_add_from_file:\n%s", error->message);
        g_clear_error(&error);
        return 1;
    }

    // VENTANAS
    VENTANA_INICIO = GTK_WIDGET(gtk_builder_get_object(builder, "ventana_principal"));
    VENTANA_QUIEN=GTK_WIDGET(gtk_builder_get_object(builder, "VENTANA_QUIEN"));
    VENTANA_MODO_DE_JUEGO = GTK_WIDGET(gtk_builder_get_object(builder, "VENTANA_MODO_DE_JUEGO"));
    VENTANA_CREDITOS=GTK_WIDGET(gtk_builder_get_object(builder, "VENTANA_CREDITOS"));
    VENTANA_PUNTUACIONES=GTK_WIDGET(gtk_builder_get_object(builder, "VENTANA_PUNTUACIONES"));
    VENTANA_PARTIDAS=GTK_WIDGET(gtk_builder_get_object(builder, "VENTANA_PARTIDAS"));
    VENTANA_PERSONAJE=GTK_WIDGET(gtk_builder_get_object(builder, "VENTANA_PERSONAJE"));
    VENTANA_TABLERO=GTK_WIDGET(gtk_builder_get_object(builder, "VENTANA_TABLERO"));
    VENTANA_DOSJUGADORES=GTK_WIDGET(gtk_builder_get_object(builder, "VENTANA_DOSJUGADORES"));
    VENTANA_UNJUGADOR=GTK_WIDGET(gtk_builder_get_object(builder, "VENTANA_UNJUGADOR"));
    VENTANA_PAUSA=GTK_WIDGET(gtk_builder_get_object(builder, "VENTANA_PAUSA"));
    VENTANA_COMO=GTK_WIDGET(gtk_builder_get_object(builder, "VENTANA_COMO"));
    VENTANA_GANADOR_ROJO=GTK_WIDGET(gtk_builder_get_object(builder, "VENTANA_GANADOR_ROJO"));
    VENTANA_GANADOR_VERDE=GTK_WIDGET(gtk_builder_get_object(builder, "VENTANA_GANADOR_VERDE"));

    //BOTONES CREDITOS
    ATRAS_CREDITOS = GTK_WIDGET(gtk_builder_get_object(builder, "ATRAS_CREDITOS"));
    g_signal_connect(ATRAS_CREDITOS, "clicked", G_CALLBACK(CambiarVen), GINT_TO_POINTER(ATRAS));
    //BOTONES PUNTUACIONES
    ATRAS_PUNTUACIONES = GTK_WIDGET(gtk_builder_get_object(builder, "ATRAS_PUNTUACIONES"));
    g_signal_connect(ATRAS_PUNTUACIONES, "clicked", G_CALLBACK(CambiarVen), GINT_TO_POINTER(ATRAS));
    //BOTONES PARTIDAS GUARDADAS
    ATRAS_PARTIDAS = GTK_WIDGET(gtk_builder_get_object(builder, "ATRAS_PARTIDAS"));
    g_signal_connect(ATRAS_PARTIDAS, "clicked", G_CALLBACK(CambiarVen), GINT_TO_POINTER(ATRAS));
    // BOTONES VENTANA PRINCIPAL
    BOTON_INIC = GTK_WIDGET(gtk_builder_get_object(builder, "BOTON_INIC"));
    g_signal_connect(BOTON_INIC, "clicked", G_CALLBACK(CambiarVen), GINT_TO_POINTER(abrirmododejuego));
    BOTON_CREDITO=GTK_WIDGET(gtk_builder_get_object(builder, "BOTON_CREDITO"));
    g_signal_connect(BOTON_CREDITO, "clicked", G_CALLBACK(CambiarVen), GINT_TO_POINTER(abrircreditos));
    BOTON_PUNTUACIONES= GTK_WIDGET(gtk_builder_get_object(builder,"BOTON_PUNTUACIONES"));
    g_signal_connect(BOTON_PUNTUACIONES, "clicked", G_CALLBACK(CambiarVen), GINT_TO_POINTER(abrirpuntuaciones));
    BOTON_PARTIDAS= GTK_WIDGET(gtk_builder_get_object(builder,"BOTON_PARTIDAS"));
    g_signal_connect(BOTON_PARTIDAS, "clicked", G_CALLBACK(CambiarVen), GINT_TO_POINTER(abrirpartidas));
    BOTON_SALIR=GTK_WIDGET(gtk_builder_get_object(builder,"BOTON_SALIR"));
    g_signal_connect(BOTON_SALIR, "clicked", G_CALLBACK(gtk_main_quit), NULL);

    // BOTONES MODO DE JUEGO
    HvsH=GTK_WIDGET(gtk_builder_get_object(builder,"HvsH"));
    g_signal_connect(HvsH, "clicked", G_CALLBACK(EleccionModo), GINT_TO_POINTER(humanovshumano));
    HvsC=GTK_WIDGET(gtk_builder_get_object(builder,"HvsC"));
    g_signal_connect(HvsC, "clicked", G_CALLBACK(EleccionModo), GINT_TO_POINTER(humanovscompu));
    modo_aleatorio=GTK_WIDGET(gtk_builder_get_object(builder,"modo_aleatorio"));
    g_signal_connect(modo_aleatorio, "clicked", G_CALLBACK(EleccionModo), GINT_TO_POINTER(modoaleatorio));
    atras_modo=GTK_WIDGET(gtk_builder_get_object(builder,"atras_modo"));
    g_signal_connect(atras_modo, "clicked", G_CALLBACK(CambiarVen), GINT_TO_POINTER(ATRAS));

    //BOTONES QUIEN INICIA
    ALEA=GTK_WIDGET(gtk_builder_get_object(builder,"ALEA"));
    g_signal_connect(ALEA, "clicked", G_CALLBACK(QUIENINIC), GINT_TO_POINTER(3));

    JUG1=GTK_WIDGET(gtk_builder_get_object(builder,"JUG1"));
    g_signal_connect(JUG1, "clicked", G_CALLBACK(QUIENINIC), GINT_TO_POINTER(1));

    JUG2=GTK_WIDGET(gtk_builder_get_object(builder,"JUG2"));
    g_signal_connect(JUG2, "clicked", G_CALLBACK(QUIENINIC), GINT_TO_POINTER(2));

    ATRAS_QUIEN=GTK_WIDGET(gtk_builder_get_object(builder,"ATRAS_QUIEN"));
    g_signal_connect(ATRAS_QUIEN, "clicked", G_CALLBACK(CambiarVen), GINT_TO_POINTER(ATRAS));


    //BOTONES PERSONAJE
    PersonajeAleatorio=GTK_WIDGET(gtk_builder_get_object(builder,"PersonajeAleatorio"));
    g_signal_connect(PersonajeAleatorio, "clicked", G_CALLBACK(Eleccionpersonaje), GINT_TO_POINTER(modoaleatorio));

    SERMARIO=GTK_WIDGET(gtk_builder_get_object(builder,"SERMARIO"));
    g_signal_connect(SERMARIO, "clicked", G_CALLBACK(Eleccionpersonaje), GINT_TO_POINTER(SOYMARIO));

    SERLUIGI=GTK_WIDGET(gtk_builder_get_object(builder,"SERLUIGI"));
    g_signal_connect(SERLUIGI, "clicked", G_CALLBACK(Eleccionpersonaje), GINT_TO_POINTER(SOYLUIGI));

    ATRAS_PERSONAJE=GTK_WIDGET(gtk_builder_get_object(builder,"ATRAS_PERSONAJE"));
    g_signal_connect(ATRAS_PERSONAJE, "clicked", G_CALLBACK(CambiarVen), GINT_TO_POINTER(ATRAS));

    //BOTONES DOS JUGADORES
    JUGADOR1 = GTK_ENTRY(gtk_builder_get_object(builder, "JUGADOR1"));

    JUGADOR2 = GTK_ENTRY(gtk_builder_get_object(builder, "JUGADOR2"));

    LISTO_DOS_JUGADORES=GTK_WIDGET(gtk_builder_get_object(builder,"LISTO_DOS_JUGADORES"));
    g_signal_connect(LISTO_DOS_JUGADORES, "clicked", G_CALLBACK(nombrejugadores), GINT_TO_POINTER(definirjugadores));

    ATRAS_DOS_JUGADORES=GTK_WIDGET(gtk_builder_get_object(builder,"ATRAS_DOS_JUGADORES"));
    g_signal_connect(ATRAS_DOS_JUGADORES, "clicked", G_CALLBACK(CambiarVen), GINT_TO_POINTER(ATRAS));

    //BOTONES DOS JUGADORES
    JUGADOR_1 = GTK_ENTRY(gtk_builder_get_object(builder, "JUGADOR_1"));

    LISTO_UN_JUGADOR=GTK_WIDGET(gtk_builder_get_object(builder,"LISTO_UN_JUGADOR"));
    g_signal_connect(LISTO_UN_JUGADOR, "clicked", G_CALLBACK(nombrejugadores), GINT_TO_POINTER(definirjugadores));

    ATRAS_UN_JUGADOR=GTK_WIDGET(gtk_builder_get_object(builder,"ATRAS_UN_JUGADOR"));
    g_signal_connect(ATRAS_UN_JUGADOR, "clicked", G_CALLBACK(CambiarVen), GINT_TO_POINTER(ATRAS));


    // VENTANA TABLERO
    IMAGEN_TURNO = GTK_IMAGE(gtk_builder_get_object(builder, "IMAGEN_TURNO"));
    GRID_TABLERO=GTK_GRID(gtk_builder_get_object(builder, "GRID_TABLERO"));
    LABEL_TURNO= GTK_WIDGET(gtk_builder_get_object(builder, "LABEL_TURNO"));
    LABEL_AVISOS= GTK_WIDGET(gtk_builder_get_object(builder, "LABEL_AVISOS"));
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 5; j++) {
            // Construir el nombre del botón según la convención de nombres en Glade
            gchar *button_name = g_strdup_printf("boton_%d,%d", (i + 1), (j + 1));

            // Obtener una referencia al botón
            botones_tablero[i][j] = GTK_WIDGET(gtk_builder_get_object(builder, button_name));

            // Liberar la memoria asignada para el nombre del botón
            g_free(button_name);
            // Conectar la función de devolución de llamada al botón
            g_signal_connect(botones_tablero[i][j], "clicked", G_CALLBACK(juegoGTK), GINT_TO_POINTER(i * 10 + j));

        }
    }

    //VENTANA COMER
    LISTO_COMER=GTK_WIDGET(gtk_builder_get_object(builder,"LISTO_COMER"));

    	jugar_compu=GTK_WIDGET(gtk_builder_get_object(builder,"jugar_compu"));
        g_signal_connect(jugar_compu, "clicked", G_CALLBACK(juegoGTK), NULL);


    g_signal_connect(LISTO_COMER, "clicked", G_CALLBACK(listocomer), NULL);

    //VENTANA pausa entre otros
    ATRAS_COMO=GTK_WIDGET(gtk_builder_get_object(builder,"ATRAS_COMO"));
    g_signal_connect(ATRAS_COMO, "clicked", G_CALLBACK(CambiarVen), GINT_TO_POINTER(ATRAS));

    BOTON_PAUSA=GTK_WIDGET(gtk_builder_get_object(builder,"BOTON_PAUSA"));
    g_signal_connect(BOTON_PAUSA, "clicked", G_CALLBACK(CambiarVen), GINT_TO_POINTER(ATRAS));

    medio= GTK_IMAGE(gtk_builder_get_object(builder, "medio"));
    SEGUIR_JUGANDO=GTK_WIDGET(gtk_builder_get_object(builder,"SEGUIR_JUGANDO"));
    g_signal_connect(SEGUIR_JUGANDO, "clicked", G_CALLBACK(CambiarVen), GINT_TO_POINTER(ATRAS));
    COMO_SE_JUEGA=GTK_WIDGET(gtk_builder_get_object(builder,"COMO_SE_JUEGA"));
    g_signal_connect(COMO_SE_JUEGA, "clicked", G_CALLBACK(CambiarVen), GINT_TO_POINTER(comosejuega));
    //VOLVER_AL_MENU=GTK_WIDGET(gtk_builder_get_object(builder,"VOLVER_AL_MENU"));
    //g_signal_connect(VOLVER_AL_MENU, "clicked", G_CALLBACK(volvermenu), GINT_TO_POINTER(comosejuega));
    SALIR_JUEGO=GTK_WIDGET(gtk_builder_get_object(builder,"SALIR_JUEGO"));
    g_signal_connect(SALIR_JUEGO, "clicked", G_CALLBACK(gtk_main_quit), NULL);
    FINALIZAR=GTK_WIDGET(gtk_builder_get_object(builder,"FINALIZAR"));
    g_signal_connect(FINALIZAR, "clicked", G_CALLBACK(final_del_juego), NULL);
    PAUSA_VERDE=GTK_WIDGET(gtk_builder_get_object(builder,"PAUSA_VERDE"));
    g_signal_connect(PAUSA_VERDE, "clicked", G_CALLBACK(gtk_main_quit), GINT_TO_POINTER(comosejuega));

    PAUSA_RO=GTK_WIDGET(gtk_builder_get_object(builder,"PAUSA_RO"));
    g_signal_connect(PAUSA_RO, "clicked", G_CALLBACK(gtk_main_quit), GINT_TO_POINTER(comosejuega));
    RELLENAR=GTK_WIDGET(gtk_builder_get_object(builder,"RELLENAR"));
    g_signal_connect(RELLENAR, "clicked", G_CALLBACK(rellenar), GINT_TO_POINTER(comosejuega));

    // Conectar la señal de "destroy" para cerrar la aplicación correctamente
    g_signal_connect(VENTANA_INICIO, "destroy", G_CALLBACK(gtk_main_quit), NULL);

    // Mostrar la ventana principal
    gtk_widget_show_all(VENTANA_INICIO);

    gtk_main();

    // Liberar recursos
    g_object_unref(builder);
    return 0;
}
