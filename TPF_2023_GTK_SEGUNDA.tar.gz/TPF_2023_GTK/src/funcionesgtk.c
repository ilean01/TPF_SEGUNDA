/*
 * inicializacion.c
 *
 *  Created on: 6 oct. 2023
 *      Author: lp1-2023
 */
#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <unistd.h> // Necesario para la función sleep
#include "inicializaciones.h"

int filaAleatoria, columnaAleatoria;


int eleccion;      // Definir la variable eleccion
int eleccion2;     // Definir la variable eleccion2
int matriznum[5][5];
char jugador1, jugador2; // Jugadores 1 ('x') y 2 ('o').
char matrizlet[5][5];
const gchar * nombrejugador1;
const gchar * nombrejugador2;
int ftemp;
int ctemp;
void QUIENINIC(GtkWidget *widget, gpointer data){
	int valor = GPOINTER_TO_INT(data); // Convertir el puntero a entero
		switch (valor){
		case 3:
			srand(time(NULL));
			int numeroAleatorio = rand() % 2 + 1;
			turno=numeroAleatorio;
			gtk_widget_hide(VENTANA_QUIEN);
			gtk_widget_show_all(VENTANA_TABLERO);
			break;
		case 1:
			turno=1;
			gtk_widget_hide(VENTANA_QUIEN);
			gtk_widget_show_all(VENTANA_TABLERO);
			break;
		case 2:
			turno=2;
			gtk_widget_hide(VENTANA_QUIEN);
			gtk_widget_show_all(VENTANA_TABLERO);
			break;
			}
		casillasgtk();
}
void inicializarMatriz(){
	for (int i = 0; i < 5; i++) {
		        for (int j = 0; j < 5; j++) {
		        	matriznum[i][j]=0;
		        	matrizlet[i][j]=' ';
		        }}
}

void comerDadosAleatorio(){
	int fila=filaAleatoria;
	int columna=columnaAleatoria;

	int numerosmat[5][5];
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 5; j++) {
			if(matriznum[i][j]<6){
				numerosmat[i][j] = matriznum[i][j];
			}else{numerosmat[i][j] =0;}
		}
	}
	int suma = 0;
	int num = 0;
	int numerosComidos = 0;
	int coordenadas[4][2];

	// Comer números adyacentes
	if (fila - 1 >= 0 && numerosmat[fila - 1][columna] != 0) {
		coordenadas[num][0] = fila - 1;
		coordenadas[num][1] = columna;
		num++;
		numerosComidos++;
	}
	if (fila + 1 < 5 && numerosmat[fila + 1][columna] != 0) {
		coordenadas[num][0] = fila + 1;
		coordenadas[num][1] = columna;
		num++;
		numerosComidos++;
	}
	if (columna - 1 >= 0 && numerosmat[fila][columna - 1] != 0) {
		coordenadas[num][0] = fila;
		coordenadas[num][1] = columna - 1;
		num++;
		numerosComidos++;
	}
	if (columna + 1 < 5 && numerosmat[fila][columna + 1] != 0) {
		coordenadas[num][0] = fila;
		coordenadas[num][1] = columna + 1;
		num++;
		numerosComidos++;
	}


	int eleccion[4];

	if (numerosComidos < 2) {
		char nuevo_texto[100];
			snprintf(nuevo_texto, sizeof(nuevo_texto), "LA COMPU JUGO EN %c,%d", 'A'+(columna),fila+1);
		gtk_label_set_text(GTK_LABEL(LABEL_AVISOS), nuevo_texto);
	} else if (numerosComidos == 2) {
		int num1 = coordenadas[0][0];
		int num2 = coordenadas[0][1];
		int num3 = coordenadas[1][0];
		int num4 = coordenadas[1][1];
		suma = matriznum[num1][num2] + matriznum[num3][num4];

		if (suma <= 6) {
			char nuevo_texto[100];
			snprintf(nuevo_texto, sizeof(nuevo_texto), "LA COMPU JUGO EN %c,%d Y COMIO DOS DADOS" , 'A'+(columna),fila+1);
			gtk_label_set_text(GTK_LABEL(LABEL_TURNO), nuevo_texto);

				matriznum[fila][columna] = suma;
				matriznum[num1][num2] = 0;
				matrizlet[num1][num2] = ' ';
				matriznum[num3][num4] = 0;
				matrizlet[num3][num4] = ' ';
			}

		else {
			printf(RED"La suma de los dos adyacentes supera 6.\n"RESET);
		}
	} else if (numerosComidos > 2) {

		// Elegir números para comer de forma aleatoria
		int totalSuma = 0;
		int numComer = 0;
		int continuar = 1;

		do {
			for (int i = 0; i < numerosComidos; i++) {
				eleccion[i] = rand() % 2; // 0 o 1 de forma aleatoria

				if (eleccion[i] == 1) {
					totalSuma += matriznum[coordenadas[i][0]][coordenadas[i][1]];
					numComer++;
				}
			}

			if (numComer < 2 || totalSuma > 6) {
				totalSuma=0;

			} else {

				for (int i = 0; i < numerosComidos; i++) {
					if (eleccion[i] == 1) {

						matriznum[coordenadas[i][0]][coordenadas[i][1]] = 0;
						matrizlet[coordenadas[i][0]][coordenadas[i][1]] = ' ';
						matriznum[fila][columna]=totalSuma;
					}
				}
				continuar = 0;
			}
		} while (continuar);
		char nuevo_texto[100];
					snprintf(nuevo_texto, sizeof(nuevo_texto), "LA COMPU JUGO EN %c,%d Y COMIO %d", 'A'+(columna),fila+1,totalSuma);
				gtk_label_set_text(GTK_LABEL(LABEL_AVISOS), nuevo_texto);

		if (numComer == 0) {
			printf(RED"No se comió ningún número.\n"RESET);
		}
	}
}

int obtenerPosicionAleatoria() {
    filaAleatoria=0;
    columnaAleatoria=0;

    // Inicializa la semilla del generador de números aleatorios
    srand(time(NULL));

    do {
        filaAleatoria = rand() % 5;     // Genera un número aleatorio de 0 a 4 para la fila
        columnaAleatoria = rand() % 5;  // Genera un número aleatorio de 0 a 4 para la columna
    } while (matriznum[filaAleatoria][columnaAleatoria] != 0);
    matriznum[filaAleatoria][columnaAleatoria] = 1;
    matrizlet[filaAleatoria][columnaAleatoria]=jugador2;




    return 1;  // Éxito
}
void casillasgtk() {


    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 5; j++) {
            gchar *filename;
            GtkWidget *button= gtk_grid_get_child_at(GTK_GRID(GRID_TABLERO), i, j);

            if (matriznum[i][j] == 0) {
                // Si el valor es 0, muestra una imagen de interrogación
                filename = g_strdup("src/IMAGENES/TABLERO/interrogacion_of.jpg");
            } else {
                // Construye el nombre del archivo según la matriz
                filename = g_strdup_printf("src/IMAGENES/TABLERO/%c%d.jpg", matrizlet[i][j], matriznum[i][j]);
            }

            // Aquí asumimos que los botones tienen una propiedad "image" para mostrar imágenes
            gtk_button_set_image(GTK_BUTTON(button), gtk_image_new_from_file(filename));

            // Libera la memoria asignada para el nombre del archivo
            g_free(filename);

        }
    }
    if (turno == 1) {
    	char nuevo_texto[100];
    	snprintf(nuevo_texto, sizeof(nuevo_texto), "TURNO DEL JUGADOR:  %s", nombrejugador1);
    	gtk_label_set_text(GTK_LABEL(LABEL_TURNO), nuevo_texto);

    	if(jugador1=='x'){
    		gtk_image_set_from_file(GTK_IMAGE(IMAGEN_TURNO),"src/IMAGENES/TABLERO/hongo rojo.jpg");
    	}else{
    		gtk_image_set_from_file(GTK_IMAGE(IMAGEN_TURNO),"src/IMAGENES/TABLERO/hongo verde.jpg");
    	}
    } else {
    	char nuevo_texto[100];
    	snprintf(nuevo_texto, sizeof(nuevo_texto), "TURNO DEL JUGADOR:  %s", nombrejugador2);
    	gtk_label_set_text(GTK_LABEL(LABEL_TURNO), nuevo_texto);
    	if(jugador2=='x'){
    		gtk_image_set_from_file(GTK_IMAGE(IMAGEN_TURNO),"src/IMAGENES/TABLERO/hongo rojo.jpg");
    	}else{
    		gtk_image_set_from_file(GTK_IMAGE(IMAGEN_TURNO),"src/IMAGENES/TABLERO/hongo verde.jpg");
    	}
    }
    printf("Actualizando interfaz gráfica en casillasgtk()\n");
    if(ll==0){
    	gtk_widget_set_visible(jugar_compu, FALSE);
    	gtk_widget_set_visible(LISTO_COMER, FALSE);
    	gtk_widget_set_visible(FINALIZAR, FALSE);
    if (eleccion2 == 1) {
            jugador1 = 'x'; // Jugador 1 eligió 'x'.
            jugador2 = 'o'; // Jugador 2 es 'o'.
        } else {
            jugador1 = 'o'; // Jugador 1 eligió 'o'.
            jugador2 = 'x'; // Jugador 2 es 'x'.
        }

                if (turno == 1) {
                	 char nuevo_texto[100];
                	 snprintf(nuevo_texto, sizeof(nuevo_texto), "TURNO DEL JUGADOR:  %s", nombrejugador1);
                	 gtk_label_set_text(GTK_LABEL(LABEL_TURNO), nuevo_texto);

                    if(jugador1=='x'){
                    	gtk_image_set_from_file(GTK_IMAGE(IMAGEN_TURNO),"src/IMAGENES/TABLERO/hongo rojo.jpg");
                    }else{
                    	gtk_image_set_from_file(GTK_IMAGE(IMAGEN_TURNO),"src/IMAGENES/TABLERO/hongo verde.jpg");
                    }
                } else {
                	char nuevo_texto[100];
                	snprintf(nuevo_texto, sizeof(nuevo_texto), "TURNO DEL JUGADOR:  %s", nombrejugador2);
                	gtk_label_set_text(GTK_LABEL(LABEL_TURNO), nuevo_texto);
                    if(jugador2=='x'){
                    	gtk_image_set_from_file(GTK_IMAGE(IMAGEN_TURNO),"src/IMAGENES/TABLERO/hongo rojo.jpg");
                    }else{
                    	gtk_image_set_from_file(GTK_IMAGE(IMAGEN_TURNO),"src/IMAGENES/TABLERO/hongo verde.jpg");
                    }
                }



    }
    ll++;
}


void CambiarVen(GtkWidget *widget, gpointer data) {

    int valor = GPOINTER_TO_INT(data); // Convertir el puntero a entero

    switch (valor) {
    	case ATRAS:
    		if (gtk_widget_is_visible(VENTANA_QUIEN)) {
    			gtk_widget_hide(VENTANA_QUIEN);
    			if(eleccion==1){
    			gtk_widget_show_all(VENTANA_UNJUGADOR);}
    			else{
    				gtk_widget_show_all(VENTANA_DOSJUGADORES);
    			}
    			break;
    		}
    		if (gtk_widget_is_visible(VENTANA_PAUSA)) {
    		    gtk_widget_hide(VENTANA_PAUSA);
    		    gtk_widget_show_all(VENTANA_TABLERO);
    		    break;
    		    }

    		if (gtk_widget_is_visible(VENTANA_TABLERO)) {
    			gtk_widget_hide(VENTANA_TABLERO);
    			gtk_widget_show_all(VENTANA_PAUSA);
    			break;
    		}
    		if (gtk_widget_is_visible(VENTANA_PARTIDAS)) {
    			gtk_widget_hide(VENTANA_PARTIDAS);
    			gtk_widget_show_all(VENTANA_INICIO);
    			break;
    		}
    		if (gtk_widget_is_visible(VENTANA_PUNTUACIONES)) {
    			gtk_widget_hide(VENTANA_PUNTUACIONES);
    			gtk_widget_show_all(VENTANA_INICIO);
    			break;
    		}
    	    if (gtk_widget_is_visible(VENTANA_CREDITOS)) {
    	        gtk_widget_hide(VENTANA_CREDITOS);
    	        gtk_widget_show_all(VENTANA_INICIO);
    	        break;
    	    }

    	    if (gtk_widget_is_visible(VENTANA_MODO_DE_JUEGO)) {
    	        gtk_widget_hide(VENTANA_MODO_DE_JUEGO);
    	        gtk_widget_show_all(VENTANA_INICIO);
    	        break;
    	    }
    	    if (gtk_widget_is_visible(VENTANA_PERSONAJE)) {
    	    	gtk_widget_hide(VENTANA_PERSONAJE);
    	    	gtk_widget_show_all(VENTANA_MODO_DE_JUEGO);
    	    	break;
    	    }
    	    if (gtk_widget_is_visible(VENTANA_DOSJUGADORES)) {
    	    	gtk_widget_hide(VENTANA_DOSJUGADORES);
    	    	gtk_widget_show_all(VENTANA_PERSONAJE);
    	    	break;
    	    }
    	    if (gtk_widget_is_visible(VENTANA_UNJUGADOR)) {
    	    	gtk_widget_hide(VENTANA_UNJUGADOR);
    	    	gtk_widget_show_all(VENTANA_PERSONAJE);
    	    	break;
    	    }
    	    if (gtk_widget_is_visible(VENTANA_COMO)) {
    	    	gtk_widget_hide(VENTANA_COMO);
    	    	gtk_widget_show_all(VENTANA_PAUSA);
    	    	break;
    	    }

    		break;
        case abrirmododejuego:
            // Mostramos ventanas y escondemos otras
            gtk_widget_hide(VENTANA_INICIO);
            gtk_widget_show_all(VENTANA_MODO_DE_JUEGO);
            break;
    case abrircreditos:
		gtk_widget_hide(VENTANA_INICIO);
    	gtk_widget_show_all(VENTANA_CREDITOS);
    	break;
    case abrirpuntuaciones:
    	gtk_widget_hide(VENTANA_INICIO);
    	gtk_widget_show_all(VENTANA_PUNTUACIONES);
    	break;
    case abrirpartidas:
    	gtk_widget_hide(VENTANA_INICIO);
    	gtk_widget_show_all(VENTANA_PARTIDAS);
    	break;
    case comosejuega:
    	gtk_widget_hide(VENTANA_PAUSA);
    	gtk_widget_show_all(VENTANA_COMO);
    	break;


}}
void EleccionModo(GtkWidget *widget, gpointer data){
	int valor = GPOINTER_TO_INT(data); // Convertir el puntero a entero
	switch (valor){
	case humanovshumano:
		eleccion = 2;
		gtk_widget_hide(VENTANA_MODO_DE_JUEGO);
		gtk_widget_show_all(VENTANA_PERSONAJE);
		break;
	case humanovscompu:
		eleccion=1;
		gtk_widget_hide(VENTANA_MODO_DE_JUEGO);
		gtk_widget_show_all(VENTANA_PERSONAJE);
		break;
	case modoaleatorio:
		srand(time(NULL));
		int numeroAleatorio = rand() % 2 + 1;
		eleccion=numeroAleatorio;
		gtk_widget_hide(VENTANA_MODO_DE_JUEGO);
		gtk_widget_show_all(VENTANA_PERSONAJE);
		break;
	}
}
void Eleccionpersonaje(GtkWidget *widget, gpointer data){
	int valor = GPOINTER_TO_INT(data); // Convertir el puntero a entero
	if(eleccion == 2){//modo de juago para dos jugadores
	switch (valor){
	case modoaleatorio:
		srand(time(NULL));
		int numeroAleatorio = rand() % 2 + 1;
		eleccion2=numeroAleatorio;
		gtk_widget_hide(VENTANA_PERSONAJE);
		gtk_widget_show_all(VENTANA_DOSJUGADORES);
		break;
	case SOYMARIO:
		eleccion2=1;
		gtk_widget_hide(VENTANA_PERSONAJE);
		gtk_widget_show_all(VENTANA_DOSJUGADORES);
		break;
	case SOYLUIGI:
		eleccion2=2;
		gtk_widget_hide(VENTANA_PERSONAJE);
		gtk_widget_show_all(VENTANA_DOSJUGADORES);
		break;
		}
}
	else{
		switch (valor){
			case modoaleatorio:
				srand(time(NULL));
				int numeroAleatorio = rand() % 2 + 1;
				eleccion2=numeroAleatorio;
				gtk_widget_hide(VENTANA_PERSONAJE);
				gtk_widget_show_all(VENTANA_UNJUGADOR);
				break;
			case SOYMARIO:
				eleccion2=1;
				gtk_widget_hide(VENTANA_PERSONAJE);
				gtk_widget_show_all(VENTANA_UNJUGADOR);
				break;
			case SOYLUIGI:
				eleccion2=2;
				gtk_widget_hide(VENTANA_PERSONAJE);
				gtk_widget_show_all(VENTANA_UNJUGADOR);
				break;
				}
	}
}
void nombrejugadores(GtkWidget *button, gpointer user_data) {
	if(eleccion == 2){//modo de juago para dos jugadores
		 // Obtener el texto ingresado en el GtkEntry
		    const gchar *texto1 = gtk_entry_get_text(JUGADOR1);
		    const gchar *texto2 = gtk_entry_get_text(JUGADOR2);
		    // Asignar memoria y copiar el texto
		    nombrejugador1= g_strdup(texto1);
		    nombrejugador2= g_strdup(texto2);
		    gtk_widget_hide(VENTANA_DOSJUGADORES);
		   gtk_widget_show_all(VENTANA_QUIEN);

	}
	else{
		nombrejugador2="COMPUTADORA";
		const gchar *texto1 = gtk_entry_get_text(JUGADOR1);
		nombrejugador1= g_strdup(texto1);
		gtk_widget_hide(VENTANA_UNJUGADOR);
		gtk_widget_show_all(VENTANA_QUIEN);

		;
	}


}

// Funciones de las señales de los botones toggle
int coordenadas[4][2];
// Función para convertir botones normales en botones de alternancia

int arri=0;
int abb=0;
int izz=0;
int deer=0;
int apre;
int sumas;
void cualseapreto(GtkToggleButton *togglebutton, gpointer user_data){

	sumas=0;
	int valor = GPOINTER_TO_INT(user_data);
	switch(valor){
	case 0:
	if (gtk_toggle_button_get_active(togglebutton)) {
	       sumas=sumas+matriznum[coordenadas[0][0]][coordenadas[0][1]];
	       apre++;
	       abb=1;
	    } else {
	    	sumas=sumas-matriznum[coordenadas[0][0]][coordenadas[0][1]];
	    	apre--;
	    	abb=0;
	    }

	break;
	case 1:
		if (gtk_toggle_button_get_active(togglebutton)) {
		       sumas=sumas+matriznum[coordenadas[1][0]][coordenadas[1][1]];
		       arri=1;
		       apre++;
		    } else {
		    	sumas=sumas-matriznum[coordenadas[1][0]][coordenadas[1][1]];
		    	apre--;
		    	arri=0;
		    }
		break;
	case 2:
		if (gtk_toggle_button_get_active(togglebutton)) {
		       sumas=sumas+matriznum[coordenadas[2][0]][coordenadas[2][1]];
		       apre++;
		       izz=1;
		    } else {
		    	sumas=sumas-matriznum[coordenadas[2][0]][coordenadas[2][1]];
		    	izz=0;
		    	apre--;
		    }
		break;
		case 3:
			if (gtk_toggle_button_get_active(togglebutton)) {
			       sumas=sumas+matriznum[coordenadas[3][0]][coordenadas[3][1]];
			       apre++;
			       deer=1;
			    } else {
			    	sumas=sumas-matriznum[coordenadas[3][0]][coordenadas[3][1]];
			    	apre--;
			    	deer=0;
			    }
			break;
	}

	if ((apre>=2 && sumas<7)||apre==0){
		gtk_widget_set_visible(LISTO_COMER, TRUE);
	}
	else{
		gtk_widget_set_visible(LISTO_COMER, FALSE);
	}

	}

void convertirANormales() {
	for (int i = 0; i < 5; i++) {
		        for (int j = 0; j < 5; j++) {
		        	gtk_widget_set_sensitive(GTK_WIDGET(botones_tablero[i][j]), TRUE);

		        }}
	for (int i = 0; i < 4; i++) {
	        if (coordenadas[i][0] != 9) {
	            // Obtener las coordenadas actuales
	            int fila = coordenadas[i][1];
	            int columna = coordenadas[i][0];

	            // Obtener el antiguo botón de alternancia
	            GtkWidget *viejo_boton = botones_tablero[fila][columna];

	            // Obtener el texto del antiguo botón
	            const gchar *texto_actual = gtk_button_get_label(GTK_BUTTON(viejo_boton));

	            // Crear un nuevo botón normal con el mismo texto
	            GtkWidget *nuevo_boton = gtk_button_new_with_label(texto_actual);

	            // Conectar la señal 'clicked' al nuevo botón
	            g_signal_connect(nuevo_boton, "clicked", G_CALLBACK(juegoGTK), GINT_TO_POINTER(fila * 10 + columna));

	            // Eliminar el antiguo botón de alternancia del contenedor
	            gtk_container_remove(GTK_CONTAINER(GRID_TABLERO), viejo_boton);

	            // Reemplazar el antiguo botón con el nuevo en la matriz
	            botones_tablero[fila][columna] = nuevo_boton;

	            // Actualizar la matriz de botones
	            gtk_grid_attach(GTK_GRID(GRID_TABLERO), nuevo_boton, columna, fila, 1, 1);

	            // Ocultar el antiguo botón de alternancia


	            // Mostrar el nuevo botón
	            gtk_widget_show(nuevo_boton);
	        }
	    }

	    // Luego de realizar todas las conversiones, mostrar la interfaz gráfica
	    casillasgtk();
	    for (int i = 0; i < 5; i++) {
	    	for (int j = 0; j < 5; j++) {
	    		gtk_widget_set_sensitive(GTK_WIDGET(botones_tablero[i][j]), TRUE);
	    	}}
}

// Función para convertir botones de alternancia en botones normales
void convertirAAlternancia() {

	 for (int i = 0; i < 5; i++) {
	        for (int j = 0; j < 5; j++) {
	        	gtk_widget_set_sensitive(GTK_WIDGET(botones_tablero[i][j]), FALSE);

	        }}
	 for (int i = 0; i < 4; i++) {
	         if (coordenadas[i][0] != 9) {

	             // Obtener las coordenadas actuales
	             int fila = coordenadas[i][1];
	             int columna = coordenadas[i][0];

	             // Obtener el antiguo botón
	             GtkWidget *viejo_boton = botones_tablero[fila][columna];

	             // Obtener el texto del antiguo botón
	             const gchar *texto_actual = gtk_button_get_label(GTK_BUTTON(viejo_boton));

	             // Crear un nuevo botón de alternancia con el mismo texto
	             GtkWidget *nuevo_boton = gtk_toggle_button_new_with_label(texto_actual);

	             // Conectar la señal 'toggled' al nuevo botón
	             g_signal_connect(nuevo_boton, "toggled", G_CALLBACK(cualseapreto), GINT_TO_POINTER(i));

	             // Reemplazar el antiguo botón con el nuevo en la matriz
	             botones_tablero[fila][columna] = nuevo_boton;

	             // Actualizar la matriz de botones
	             gtk_grid_attach(GTK_GRID(GRID_TABLERO), nuevo_boton, columna, fila, 1, 1);
	             gtk_widget_hide(viejo_boton);
	             // Mostrar el nuevo botón
	             gtk_widget_show(nuevo_boton);

	             // Ocultar el antiguo botón

	         }
	     }
	 gtk_widget_set_visible(LISTO_COMER, TRUE);
}

void listocomer(){

	summ=0;
	if (apre==0){
		gtk_label_set_text(GTK_LABEL(LABEL_AVISOS), "NO COMIO NINGUN DADO");
		matriznum[ftemp][ctemp]=1;
	}else if(apre==1){
		gtk_label_set_text(GTK_LABEL(LABEL_AVISOS), "NO COMIO LOS SUFICIENTES DADOS");
	}else{

	if (arri==1){
		 summ+=matriznum[coordenadas[1][0]][coordenadas[1][1]];
	}
	if(abb==1){summ+=matriznum[coordenadas[0][0]][coordenadas[0][1]];}
	if(izz==1){summ+=matriznum[coordenadas[2][0]][coordenadas[2][1]];}
	if(deer==1){summ+=matriznum[coordenadas[3][0]][coordenadas[3][1]];}

	}if(summ>6){gtk_label_set_text(GTK_LABEL(LABEL_AVISOS), "LA SUMA DE LOS DADOS SELECCIONADOS SUPERO 6.");
	matriznum[ftemp][ctemp]=1;
	}
	else{
		if(summ==0){
			gtk_label_set_text(GTK_LABEL(LABEL_AVISOS), "NO SE HAN COMIDO DADOS");
			matriznum[ftemp][ctemp]=1;
		}else{
			gtk_label_set_text(GTK_LABEL(LABEL_AVISOS), "SE HAN COMIDO DADOS");

		matriznum[ftemp][ctemp]=summ;}
		if (arri==1){
				matriznum[coordenadas[1][0]][coordenadas[1][1]]=0;
				matrizlet[coordenadas[1][0]][coordenadas[1][1]]=' ';
		}
		if(abb==1){
			matriznum[coordenadas[0][0]][coordenadas[0][1]]=0;
			matrizlet[coordenadas[0][0]][coordenadas[0][1]]=' ';
		}
		if(izz==1){
			matriznum[coordenadas[2][0]][coordenadas[2][1]]=0;
			matrizlet[coordenadas[2][0]][coordenadas[2][1]]=' ';
		}
		if(deer==1){
			matriznum[coordenadas[3][0]][coordenadas[3][1]]=0;
			matrizlet[coordenadas[3][0]][coordenadas[3][1]]=' ';
		}

	}
	convertirANormales();

	gtk_widget_set_visible(LISTO_COMER, FALSE);


	casillasgtk();




}
void comerDados(int fila, int columna){

	 apre=0;
	ftemp=fila;
	ctemp=columna;


	arri=0;
	abb=0;
	izz=0;
	deer=0;
    int suma = 0;
    int num = 0;
    int numerosComidos = 0;
    for (int i = 0; i < 4; ++i) {
        // Bucle para columnas
        for (int j = 0; j < 2; ++j) {
            coordenadas[i][j] = 9; // Inicializa cada elemento con 0
        }
    }


    // Comer números adyacentes
    if (fila - 1 >= 0 && matriznum[fila - 1][columna] != 0 && matriznum[fila - 1][columna] != 6) {//ABAJO


        coordenadas[0][0] = fila - 1;
        coordenadas[0][1] = columna;
        num++;
        numerosComidos++;

    }


    if (fila + 1 < 5 && matriznum[fila + 1][columna] != 0 && matriznum[fila + 1][columna] != 6 ) {//ARRIBA


        coordenadas[1][0] = fila + 1;
        coordenadas[1][1] = columna;
        num++;
        numerosComidos++;
    }
    if (columna - 1 >= 0 && matriznum[fila][columna - 1] != 0 && matriznum[fila][columna - 1] != 6) {//IZQ



        coordenadas[2][0] = fila;
        coordenadas[2][1] = columna - 1;
        num++;
        numerosComidos++;
    }
    if (columna + 1 < 5 && matriznum[fila][columna + 1] != 0 && matriznum[fila][columna + 1] != 6) {//DER


        coordenadas[3][0] = fila;
        coordenadas[3][1] = columna +1;
        numerosComidos++;
    }


       if (numerosComidos < 2) {
    	   gtk_label_set_text(GTK_LABEL(LABEL_AVISOS), "NO HAY SUFICIENTES ADYACENTES QUE COMER");
       }
       else if (numerosComidos == 2) {
    	   for (int i=0;i<4;i++){
    	   if(coordenadas[i][0]!=9){
    		   suma+=matriznum[coordenadas[i][0]][coordenadas[i][1]];
    	   }
    	   }
           if (suma <= 6) {
        	gtk_label_set_text(GTK_LABEL(LABEL_AVISOS), "SE COMIERON 2 DADOS.");

           	matriznum[fila][columna] = suma;
           	for (int i=0;i<4;i++){
           	    	   if(coordenadas[i][0]!=9){
           	    		matriznum[coordenadas[i][0]][coordenadas[i][1]]=0;
           	    		matrizlet[coordenadas[i][0]][coordenadas[i][1]]=' ';
           	    	   }
               }
           }
    	   }
       else{

    	   casillasgtk();
    	   gtk_label_set_text(GTK_LABEL(LABEL_AVISOS), "ELIJE QUE DADOS QUIERES COMER");
    	   gtk_widget_set_visible(jugar_compu, FALSE);
    	   gtk_widget_set_visible(LISTO_COMER, TRUE);



    	   convertirAAlternancia();


       }






       }

void realizarJugadaComputadora() {


    // Lógica para obtener una posición aleatoria para la computadora
    obtenerPosicionAleatoria();


    casillasgtk();

    // Lógica para realizar la jugada y comer dados de forma aleatoria
    comerDadosAleatorio();

    // Cambiar el turno de nuevo al jugador humano


    // Actualizar la interfaz gráfica u otras operaciones necesarias
    casillasgtk();
}
void final_del_juego(){
	int jugx=0;
	int jugo=0;

	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 5; j++) {
			if(matrizlet[i][j]=='x'){
				jugx++;
			}
			else{
				jugo++;
			}
		}}
	if(jugo>jugx){
		 gtk_widget_hide(VENTANA_TABLERO);

		 gtk_widget_show_all(VENTANA_GANADOR_VERDE);
	}
	else{
		gtk_widget_hide(VENTANA_TABLERO);
		gtk_widget_show_all(VENTANA_GANADOR_VERDE);
	}
}



int juegoGTK(GtkWidget *widget, gpointer data){

	int fila;
	int columna;
	int indice = GPOINTER_TO_INT(data);
	    // Calcular los valores de i y j
	if (indice==0){
		 columna=0;
		 fila =0;
	}else if(indice<10){
		columna =0;
		 fila  = indice;
	}
	else{
	    columna = indice / 10;
	    fila  = indice % 10;
	}
	    printf("Turno: %d, Fila: %d, Columna: %d\n", turno, fila, columna);
	    if (eleccion2 == 1) {
	    	jugador1 = 'x'; // Jugador 1 eligió 'x'.
	    	jugador2 = 'o'; // Jugador 2 es 'o'.
	    } else {
	    	jugador1 = 'o'; // Jugador 1 eligió 'o'.
	    	jugador2 = 'x'; // Jugador 2 es 'x'.
	    }
	    if (eleccion == 2) {
	    if (turno == 1) {
	    	char nuevo_texto[100];
	    	snprintf(nuevo_texto, sizeof(nuevo_texto), "TURNO DEL JUGADOR:  %s", nombrejugador1);
	    	gtk_label_set_text(GTK_LABEL(LABEL_TURNO), nuevo_texto);

	    	if(jugador1=='x'){
	    		gtk_image_set_from_file(GTK_IMAGE(IMAGEN_TURNO),"src/IMAGENES/TABLERO/hongo rojo.jpg");
	    	}else{
	    		gtk_image_set_from_file(GTK_IMAGE(IMAGEN_TURNO),"src/IMAGENES/TABLERO/hongo verde.jpg");
	    	}
	    } else {
	    	char nuevo_texto[100];
	    	snprintf(nuevo_texto, sizeof(nuevo_texto), "TURNO DEL JUGADOR:  %s", nombrejugador2);
	    	gtk_label_set_text(GTK_LABEL(LABEL_TURNO), nuevo_texto);
	    	if(jugador2=='x'){
	    		gtk_image_set_from_file(GTK_IMAGE(IMAGEN_TURNO),"src/IMAGENES/TABLERO/hongo rojo.jpg");
	    	}else{
	    		gtk_image_set_from_file(GTK_IMAGE(IMAGEN_TURNO),"src/IMAGENES/TABLERO/hongo verde.jpg");
	    	}
	    }
	    if(matriznum[fila][columna]==0){
	    	if (turno == 1) {
	    		matriznum[fila][columna] = 1; // Actualiza el tablero con el jugador 1 ('x').
	    		matrizlet[fila][columna] = jugador1;
	    	} else {
	    		matriznum[fila][columna] = 1; // Actualiza el tablero con el jugador 2 ('o').
	    		matrizlet[fila][columna] = jugador2;
	    	}

	    	}

	    else{
	    	char nuevo_texto[100];
	    	snprintf(nuevo_texto, sizeof(nuevo_texto), "LA CASILLA %c,%d ya esta ocupada", 'A'+(fila+1),columna+1);
	    	gtk_label_set_text(GTK_LABEL(LABEL_AVISOS), nuevo_texto);
	    	return 1;
	    }
	    casillasgtk(fila,columna);
	    comerDados(fila, columna);
	    casillasgtk(fila,columna);





	    turno = 3 - turno; // Alternar entre 1 y 2
	    casillasgtk(fila,columna);
	    int tab_completo = 1;
	    	                for (int i = 0; i < 5; i++) {
	    	                	for (int j = 0; j < 5; j++) {
	    	                		if (matriznum[i][j] == 0) {
	    	                			tab_completo = 0; // Al menos una casilla está vacía
	    	                			break;
	    	                		}
	    	                	}
	    	                	if (!tab_completo) {
	    	                		break; // No es necesario verificar más, ya que al menos una casilla está vacía
	    	                	}
	    	                }

	    	                if (tab_completo) {
	    	                	gtk_label_set_text(GTK_LABEL(LABEL_TURNO), "TODAS LAS CASILLAS ESTAN OCUPADAS.");
	    	                	gtk_widget_set_visible(FINALIZAR, TRUE);
	    	                	gtk_widget_set_visible(jugar_compu, FALSE);

	    	                		gtk_widget_set_visible(LISTO_COMER, FALSE);
	    	                	    	gtk_widget_set_visible(LISTO_COMER, FALSE);
	    	                	for (int i = 0; i < 5; i++) {
	    	                		for (int j = 0; j < 5; j++) {
	    	                			gtk_widget_set_sensitive(GTK_WIDGET(botones_tablero[i][j]), FALSE);
	    	                		}}

	    	                }
	    return 0;
    }
	    else if (eleccion == 1) { // Modo de juego contra la computadora.
	    	gtk_widget_set_visible(jugar_compu, FALSE);
	    		if (turno == 1) {
	    			gtk_widget_set_visible(jugar_compu, FALSE);
	    			char nuevo_texto[100];
	    			snprintf(nuevo_texto, sizeof(nuevo_texto), "TURNO DEL JUGADOR:  %s", nombrejugador1);
	    			gtk_label_set_text(GTK_LABEL(LABEL_TURNO), nuevo_texto);

	    			if(jugador1=='x'){
	    				gtk_image_set_from_file(GTK_IMAGE(IMAGEN_TURNO),"src/IMAGENES/TABLERO/hongo rojo.jpg");
	    			}else{
	    				gtk_image_set_from_file(GTK_IMAGE(IMAGEN_TURNO),"src/IMAGENES/TABLERO/hongo verde.jpg");
	    			}
	    			 if(matriznum[fila][columna]==0){
	    				 if(matriznum[fila][columna]==0){
	    					 if (turno == 1) {
	    						 matriznum[fila][columna] = 1; // Actualiza el tablero con el jugador 1 ('x').
	    						 matrizlet[fila][columna] = jugador1;
	    					 } else {
	    						 matriznum[fila][columna] = 1; // Actualiza el tablero con el jugador 2 ('o').
	    						 matrizlet[fila][columna] = jugador2;
	    					 }

	    				 }
	    			 }
	    				 else{
	    					 char nuevo_texto[100];
	    					 snprintf(nuevo_texto, sizeof(nuevo_texto), "LA CASILLA %c,%d ya esta ocupada", 'A'+(fila+1),columna+1);
	    					 gtk_label_set_text(GTK_LABEL(LABEL_AVISOS), nuevo_texto);
	    					 return 1;
	    				 }
	    				 casillasgtk(fila,columna);
	    				 gtk_widget_set_visible(jugar_compu, TRUE);

	    				 casillasgtk(fila,columna);


	    				 comerDados(fila, columna);
	    				 casillasgtk(fila,columna);



	    				 turno = 3 - turno; // Alternar entre 1 y 2

	    		} else {


	    			char nuevo_texto[100];
	    			snprintf(nuevo_texto, sizeof(nuevo_texto), "TURNO DE LA COMPUTADORA");
	    			gtk_label_set_text(GTK_LABEL(LABEL_TURNO), nuevo_texto);
	    			if(jugador2=='x'){
	    				gtk_image_set_from_file(GTK_IMAGE(IMAGEN_TURNO),"src/IMAGENES/TABLERO/hongo rojo.jpg");
	    			}else{
	    				gtk_image_set_from_file(GTK_IMAGE(IMAGEN_TURNO),"src/IMAGENES/TABLERO/hongo verde.jpg");
	    			}
	    			sleep(2);

	    			realizarJugadaComputadora();


	    			casillasgtk(fila,columna);


	    			gtk_widget_set_visible(jugar_compu, FALSE);
	    			turno = 1; // Alternar entre 1 y 2
	    			casillasgtk(fila,columna);
	    			 casillasgtk(fila,columna);
	    			 for (int i = 0; i < 5; i++) {
	    				 for (int j = 0; j < 5; j++) {
	    					 gtk_widget_set_sensitive(GTK_WIDGET(botones_tablero[i][j]), TRUE);
	    				 }}
	    			 int tab_completo = 1;
	    			 	                for (int i = 0; i < 5; i++) {
	    			 	                	for (int j = 0; j < 5; j++) {
	    			 	                		if (matriznum[i][j] == 0) {
	    			 	                			tab_completo = 0; // Al menos una casilla está vacía
	    			 	                			break;
	    			 	                		}
	    			 	                	}
	    			 	                	if (!tab_completo) {
	    			 	                		break; // No es necesario verificar más, ya que al menos una casilla está vacía
	    			 	                	}
	    			 	                }

	    			 	                if (tab_completo) {
	    			 	                	gtk_label_set_text(GTK_LABEL(LABEL_TURNO), "TODAS LAS CASILLAS ESTAN OCUPADAS.");
	    			 	                	gtk_widget_set_visible(FINALIZAR, TRUE);
	    			 	                	gtk_widget_set_visible(jugar_compu, FALSE);
	    			 	                	gtk_widget_set_visible(LISTO_COMER, FALSE);

	    			 	                	for (int i = 0; i < 5; i++) {
	    			 	                		for (int j = 0; j < 5; j++) {
	    			 	                			gtk_widget_set_sensitive(GTK_WIDGET(botones_tablero[i][j]), FALSE);
	    			 	                		}}

	    			 	                }

	    			return 1;
	    		}
	    		char nuevo_texto[100];
	    			    			snprintf(nuevo_texto, sizeof(nuevo_texto), "TURNO DE LA COMPUTADORA");
	    			    			gtk_label_set_text(GTK_LABEL(LABEL_TURNO), nuevo_texto);
	    			    			if(jugador2=='x'){
	    			    				gtk_image_set_from_file(GTK_IMAGE(IMAGEN_TURNO),"src/IMAGENES/TABLERO/hongo rojo.jpg");
	    			    			}else{
	    			    				gtk_image_set_from_file(GTK_IMAGE(IMAGEN_TURNO),"src/IMAGENES/TABLERO/hongo verde.jpg");
	    			    			}












	                int tab_completo = 1;
	                for (int i = 0; i < 5; i++) {
	                	for (int j = 0; j < 5; j++) {
	                		if (matriznum[i][j] == 0) {
	                			tab_completo = 0; // Al menos una casilla está vacía
	                			break;
	                		}
	                	}
	                	if (!tab_completo) {
	                		break; // No es necesario verificar más, ya que al menos una casilla está vacía
	                	}
	                }

	                if (tab_completo) {
	                	gtk_widget_set_visible(jugar_compu, FALSE);
	                	    	gtk_widget_set_visible(LISTO_COMER, FALSE);
	                	gtk_label_set_text(GTK_LABEL(LABEL_TURNO), "TODAS LAS CASILLAS ESTAN OCUPADAS.");
	                	gtk_widget_set_visible(jugar_compu, FALSE);
	                	gtk_widget_set_visible(LISTO_COMER, FALSE);
	                	gtk_widget_set_visible(FINALIZAR, TRUE);
	                	for (int i = 0; i < 5; i++) {
	                		for (int j = 0; j < 5; j++) {
	                			gtk_widget_set_sensitive(GTK_WIDGET(botones_tablero[i][j]), FALSE);
	                		}}


	                }
	    }
	    	return 0;

	    }


void rellenar(){
	gtk_widget_set_visible(jugar_compu, FALSE);
	gtk_widget_set_visible(LISTO_COMER, FALSE);
	srand(time(NULL));
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 5; j++) {
			// Generar un número aleatorio entre 0 y 1
						    int numeroAleatorio = rand() % 2;

						    // Mapear el número aleatorio a 'x' u 'o'
						    char simbolo = (numeroAleatorio == 0) ? 'x' : 'o';
						    matriznum[i][j]=6;
						    matrizlet[i][j]=simbolo;

			if(i==5 && j==4){
				matriznum[i][j]=0;
				matrizlet[i][j]=' ';
			}

		}}
	casillasgtk();
}

