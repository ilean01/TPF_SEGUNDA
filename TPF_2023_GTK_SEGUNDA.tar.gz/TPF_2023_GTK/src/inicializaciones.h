
/*
 * inicializacion.h
 *
 *  Created on: 6 oct. 2023
 *      Author: lp1-2023
 */
#ifndef INICIALIZACIONES_H_
#define INICIALIZACIONES_H_
#define ATRAS 99
#define abrirmododejuego 1
#define abrircreditos 2
#define abrirpuntuaciones 3
#define abrirpartidas 4
#define humanovshumano 5
#define humanovscompu 6
#define modoaleatorio 7
#define SOYMARIO 8
#define SOYLUIGI 9
#define definirjugadores 10
#define abajo 12
#define izq 13
#define der 14
#define arriba 11
#define comosejuega 15

extern GtkWidget *VENTANA_INICIO;
extern GtkWidget *VENTANA_MODO_DE_JUEGO;
extern GtkWidget *BOTON_INIC;
extern GtkWidget *VENTANA_CREDITOS;
extern GtkWidget *VENTANA_PUNTUACIONES;
extern GtkWidget *VENTANA_PARTIDAS;
extern GtkWidget *VENTANA_PERSONAJE;
extern GtkWidget *VENTANA_TABLERO;
extern GtkWidget *VENTANA_DOSJUGADORES;
extern GtkWidget *VENTANA_UNJUGADOR;
extern GtkWidget *VENTANA_COMER;
extern GtkWidget *VENTANA_PAUSA;
extern GtkWidget *VENTANA_COMO;
extern GtkWidget *VENTANA_GANADOR_ROJO;
extern GtkWidget *VENTANA_GANADOR_VERDE;
extern GtkWidget *VENTANA_QUIEN;

extern GtkEntry  *JUGADOR1;
extern GtkEntry  *JUGADOR2;

extern GtkWidget *botones_tablero[5][5];

extern GtkGrid *GRID_TABLERO;
extern GtkBuilder *builder;
extern GtkImage *IMAGEN_TURNO;
extern GtkWidget *LABEL_TURNO;
extern GtkWidget *LABEL_AVISOS;
extern GtkWidget *FINALIZAR;

extern GtkWidget *IZQ_BOTON_COMER;
extern GtkWidget *ARRIBA_BOTON_COMER;
extern GtkWidget *DER_BOTON_COMER;
extern GtkWidget *ABAJO_BOTON_COMER;
extern GtkWidget *LISTO_COMER;
extern GtkWidget *jugar_compu;
extern GtkImage *medio;

extern GtkImage *arr;
extern GtkImage *aba;
extern GtkImage *derec;
extern GtkImage *izqui;

extern GtkWidget*VOLVER_AL_MENU;
extern const gchar * nombrejugador1;
extern const gchar *nombrejugador1;
#define RESET   "\033[0m"
#define RED     "\033[31m"
#define YELLOW  "\033[33m"
#define BLUE    "\033[34m"
#define GREEN   "\033[32m"
#define MARRON  "\033[33m"
#define CYAN    "\033[36m"
#define PURPURA "\033[35m"

#define BOLD    "\033[1m"
#define Cursiva "\033[3m"
#define Subrayado "\033[4m"
#define PARPADEO "\x1b[5m"

extern int eleccion;     // Declarar extern para usar en otros archivos
extern int eleccion2;    // Declarar extern para usar en otros archivos
extern int matriznum[5][5];   // Declarar extern para usar en otros archivos
extern char matrizlet[5][5];  // Declarar extern para usar en otros archivos
extern int summ;
extern  int fila, columna; // Coordenadas en el tablero.
extern int turno; // Controla el turno actual (jugador 1 o jugador 2).
extern int ll;
void inicializarMatriz();
int juego(int eleccion, int *eleccion2, int matriznum[5][5], char matrizlet[5][5]);
void CambiarVen(GtkWidget *widget, gpointer data);
void EleccionModo(GtkWidget *widget, gpointer data);
void Eleccionpersonaje(GtkWidget *widget, gpointer data);
void nombrejugadores(GtkWidget *button, gpointer user_data);
void casillasgtk() ;
int juegoGTK(GtkWidget *widget, gpointer data);
void listocomer();
void volvermenu();
void final_del_juego();
void rellenar();
void QUIENINIC(GtkWidget *widget, gpointer data);
#endif /* INICIALIZACIONES_H_ */
